require 'spec_helper'

supported_platforms

describe 'apache2::mod_cloudflare' do
end
