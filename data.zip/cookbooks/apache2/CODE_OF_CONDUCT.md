# Community Guidelines

This project follows the Chef Community Guidelines <https://docs.chef.io/community_guidelines.html>
