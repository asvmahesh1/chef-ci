
window.onload=function() {
    chgeLogo();
}
function chgeLogo() {
    var imgs=document.getElementsByTagName("img");
    imgs[0].setAttribute("src","/css/logo.jpg");
}