# frozen_string_literal: true
require 'chefspec'
require 'chefspec/berkshelf'
