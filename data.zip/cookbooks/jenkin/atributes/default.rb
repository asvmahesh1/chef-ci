#Setting Nginx default site to false

default['nginx']['default_site_enabled'] = false

default['jenkins']['nginx']['ssl'] = false
